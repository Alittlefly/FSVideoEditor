//
//  FSToolController.h
//  FSVideoEditor
//
//  Created by Charles on 2017/7/3.
//  Copyright © 2017年 Fission. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FSToolController : UIViewController

- (void)setAPI:(NSString *)api resApi:(NSString *)resApi userName:(NSString *)name;

@end
